#!/usr/bin/env python3
"""Quorum \u2014 single entry point.

Launches the FastAPI backend (which also serves the frontend). Run:

    python main.py

Then open http://localhost:8000 in a browser.

Modes are controlled by BACKEND_MODE in your .env file:
    demo  (default)  fully offline; great for building the UI and the demo video
    live             connects to a running neuro-san server (real LLM agents)

See README.md for how to start the neuro-san server for live mode.
"""

from __future__ import annotations

import uvicorn

from backend.config import settings


def main() -> None:
    print("=" * 64)
    print("  QUORUM  \u2014  multi-agent deliberation engine")
    print(f"  mode        : {settings.backend_mode}")
    print(f"  agent net   : {settings.agent_network}")
    print(f"  llm model   : {settings.llm_model}")
    print(f"  llm key set : {settings.has_llm_key}")
    print(f"  listening   : http://{settings.app_host}:{settings.app_port}")
    print("=" * 64)
    uvicorn.run(
        "backend.app:app",
        host=settings.app_host,
        port=settings.app_port,
        reload=False,
        log_level=settings.log_level.lower(),
    )


if __name__ == "__main__":
    main()
